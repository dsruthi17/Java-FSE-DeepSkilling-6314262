package com.cognizant.springlearn.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HellosController {
    private static final Logger LOGGER = LoggerFactory.getLogger(HellosController.class);

    @GetMapping("/hellos")
    public String sayHello() {
        LOGGER.info("START - sayHello()");
        LOGGER.info("END - sayHello()");
        return "Hello World!!";
    }
}
