//package com.cognizant.springlearn;
//
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//
//@SpringBootApplication
//public class SpringLearnApplication {
//
//	public static void main(String[] args) {
//		SpringApplication.run(SpringLearnApplication.class, args);
//	}
//
//}

// ===========================================================


//package com.cognizant.springlearn;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//
//public class SpringLearnApplication {
//    private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
//	private static ApplicationContext context;
//
//    public static void main(String[] args) {
//        displayCountries();
//    }
//
//    public static void displayCountries() {
//        context = new ClassPathXmlApplicationContext("country.xml");
//
//        Country us = context.getBean("us", Country.class);
//        Country de = context.getBean("de", Country.class);
//        Country in = context.getBean("in", Country.class);
//        Country jp = context.getBean("jp", Country.class);
//        
//        LOGGER.debug("US Country : {}", us.toString());
//        LOGGER.debug("DE Country : {}", de.toString());
//        LOGGER.debug("IN Country : {}", in.toString());
//        LOGGER.info("JP Country : {}", jp.toString());
//    }
//}

//=========================================================

package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearnApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringLearnApplication.class, args);
    }
}
